"""
URL configuration for mysite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from nasa_store import views


app_name = "loja"

urlpatterns = [
    path("", views.produto, name="produto"),
    path("login/", views.login_view, name="login"),
    path("criar-conta/", views.criar_conta, name="criar_conta"),
    path("sair/", views.sair, name="sair"),
    path("finalizar/", views.finalizar_compra, name="finalizar"),
    path('', views.login_view, name='login'),
    path('categorias/', views.categorias, name='categorias'),
    path('index/', views.index, name='index'),
    path('perfil/', views.perfil, name='perfil'),
    path('sobre_nos/', views.sobre_nos, name='sobre_nos'),
    path('produtos/', views.produtos, name='produtos'),
    path('produto/<int:id>/', views.detalhes, name='produto_detalhes'),
    path('carrinho/', views.carrinho, name='carrinho'),
    path('adicionar_carrinho/<int:id>/', views.adicionar_carrinho, name='adicionar_carrinho'),
    path('remover_carrinho/<int:id>/', views.remover_carrinho, name='remover_carrinho'),
    path('admin/', admin.site.urls),
    # Catch simple .html filenames and serve corresponding templates if present.
    path('<str:page>.html', views.static_page, name='static_page'),
]
