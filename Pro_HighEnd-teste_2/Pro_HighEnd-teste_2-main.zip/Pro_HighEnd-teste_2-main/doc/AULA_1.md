# Aula 1
Seguir:
- https://docs.djangoproject.com/en/5.1/intro/tutorial01/