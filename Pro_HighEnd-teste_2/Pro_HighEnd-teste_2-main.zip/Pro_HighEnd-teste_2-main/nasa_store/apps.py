from django.apps import AppConfig


class NasaStoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nasa_store'
