from django import forms
from django.contrib.auth.models import User

class CriarContaForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(label="Confirmar senha", widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email']

    def clean(self):
        dados = super().clean()
        if dados.get("password") != dados.get("password2"):
            raise forms.ValidationError("As senhas não coincidem.")
        return dados