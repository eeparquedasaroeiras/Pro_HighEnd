# Loja virtual usando ferramenta uv

- https://moonrepo.dev/docs/proto/install

1. `uv venv`
2. `uv pip install django`
3. `uv run manage.py migrate`
4. `uv run manage.py createsuperuser`
5. `uv run manage.py runserver`